> library(qiime2R)
sv<-read_qza("Results/table-with-k-no-mitochondria-n0-chloroplast.qza")
sv$type
sv$contents
mymetadata<-read_tsv("Results/mymetadata.txt")
taxonomy<-read_qza("Results/taxonomy.qza")
head(taxonomy$data)
rootedtree<-read_qza("Results/rooted-tree.qza")
physeq<-qza_to_phyloseq(
  features="Results/table-with-k-no-mitochondria-n0-chloroplast.qza",
  tree="Results/rooted-tree.qza",
  taxonomy="Results/taxonomy.qza",
  metadata = "Results/mymetadata.txt"
)
library(tidyverse)
shannon<-read_qza("Results/shannon_vector.qza")
shannon<-shannon$data %>% rownames_to_column("SampleID")
gplots::venn(list(metadata=mymetadata$SampleID, shannon=shannon$SampleID))
ggsave("venn", height=4, width=4, device = pdf)
mymetadata<-
  mymetadata %>% 
  left_join(shannon)
mymetadata %>%
  filter(!is.na(shannon)) %>%
  ggplot(aes(x=`Donor-status`, y=shannon, fill=`Donor-status`)) +
  stat_summary(geom="bar", fun.data=mean_se, color="black") + #here black is the outline for the bars
  coord_cartesian(ylim=c(2,7)) + # adjust y-axis
  xlab("Four clinical groups") +   facet_grid(~'Shannon diversity index')
  ylab("Shannon Diversity") +
  theme_q2r() +
  scale_fill_manual(values=c("cornflowerblue","indianred")) + #specify custom colors
  theme(legend.position="none") +  #remove the legend as it isn't needed
ggsave("Shannon_diversity.pdf", height=3, width=4, device="pdf") # save a PDF 3 inches by 4 inches
#Evenness
evenness<-read_qza("qzv/alphadiversity/evenness_vector.qza")
evenness<-evenness$data %>% rownames_to_column("SampleID")
gplots::venn(list(metadata=mymetadata$SampleID, evenness=evenness$SampleID))
ggsave("vennevenness", height=4, width=4, device = pdf)
mymetadata<-
  mymetadata %>% 
  left_join(pielou_e)
mymetadata %>%
  filter(!is.na(pielou_e)) %>%
  ggplot(aes(x=`Donor-status`, y=pielou_e, fill=`Donor-status`)) +
  stat_summary(geom="bar", fun.data=mean_se, color="black") + #here black is the outline for the bars
  coord_cartesian(ylim=c(0.50,0.95)) + # adjust y-axis
  xlab("Four clinical groups") + facet_grid(~'Community evenness-pielou')
  ylab("Community Evenness") +
  theme_q2r() +
  scale_fill_manual(values=c("cornflowerblue","indianred")) + #specify custom colors
  theme(legend.position="none") + #remove the legend as it isn't needed
ggsave("evenness.pdf", height=3, width=4, device="pdf") # save a PDF 3 inches by 4 inches

#faithpd 
  faithpd<-read_qza("qzv/alphadiversity/faith_pd_vector.qza")
  faithpd<-faithpd$data %>% rownames_to_column("SampleID")
  gplots::venn(list(metadata=mymetadata$SampleID, faithpd=faithpd$SampleID))
  ggsave("vennfaithpd", height=4, width=4, device = pdf)
mymetadata<-
  mymetadata %>% 
  left_join(faithpd)
mymetadata %>%
  filter(!is.na(faithpd)) %>%
  ggplot(aes(x=`Donor-status`, y=faith_pd, fill=`Donor-status`)) +
  stat_summary(geom="bar", fun.data=mean_se, color="black") + #here black is the outline for the bars
  coord_cartesian(ylim=c(3,17)) + # adjust y-axis
  xlab("Four clinical groups") + facet_grid(~'Faith phylogenetic diversity')
  ylab("Faith PD") +
  theme_q2r() +
  scale_fill_manual(values=c("cornflowerblue","indianred")) + #specify custom colors
  theme(legend.position="none")+  #remove the legend as it isn't needed
ggsave("faithpd.pdf", height=3, width=4, device="pdf") # save a PDF 3 inches by 4 inches
  
#observed otus
obsotu<-read_qza("qzv/alphadiversity/observed_otus_vector.qza")
obsotu<-obsotu$data %>% rownames_to_column("SampleID")
  gplots::venn(list(metadata=mymetadata$SampleID, obsotu=obsotu$SampleID))
  ggsave("obs otu", height=4, width=4, device = pdf)
  
#PCOA
uwunifrac<-read_qza("Results/unweighted_unifrac_pcoa_results.qza")

uwunifrac$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  left_join(shannon) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`, size=shannon)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() +
  scale_size_continuous(name="Shannon Diversity") +
  scale_color_discrete(name="Donor-status")
ggsave("PCoA.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches

#uwunifrac
uwunifrac<-read_qza("qzv/betadiversity/unweighted_unifrac_pcoa_results.qza")
uwunifrac$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() + facet_grid(~'Unweighted unifrac')
  scale_color_discrete(name="Donor-status")
ggsave("unweightedPCoA.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches


#brays-curtis
Brays<-read_qza("qzv/betadiversity/bray_curtis_pcoa_results.qza")
Brays$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() + facet_grid(~'Bray Curtis')
scale_color_discrete(name="Donor-status")
ggsave("Braycurtis.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches

#Jaccard
jaccard<-read_qza("qzv/betadiversity/jaccard_pcoa_results.qza")
jaccard$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() + facet_grid(~'Jaccard')
scale_color_discrete(name="Donor-status")
ggsave("jaccard.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches


#wunifrac
wunifrac<-read_qza("qzv/betadiversity/weighted_unifrac_pcoa_results.qza")
wunifrac$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() + facet_grid(~'Weighted unifrac')
scale_color_discrete(name="Donor-status")
ggsave("WeightedPCoA.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches


#heatmap
sv<-read_qza("qzv/table-with-k-no-mitochondria-n0-chloroplast.qza")$data
taxonomy<-read_qza("taxonomy.qza")$data %>% parse_taxonomy()
taxasumsgenus<-summarize_taxa(sv, taxonomy)$Genus
taxa_heatmap(taxasumsgenus, mymetadata, "Donor-status")
ggsave("heatmapgenus", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches

taxasumsPhylum<-summarize_taxa(sv, taxonomy)$Phylum
taxa_heatmap(taxasumsPhylum, mymetadata, "Donor-status")
ggsave("heatmapPhylum", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches

taxasumsSpecies<-summarize_taxa(sv, taxonomy)$Species
taxa_heatmap(taxasumsSpecies, mymetadata, "Donor-status")
ggsave("heatmapSpecies", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches

library(tidyverse)

taxa_barplot(taxasumsgenus, mymetadata, "Donor-status")
ggsave("barplotgenus", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches


taxa_barplot(taxasumsPhylum, mymetadata, "Donor-status")
ggsave("barplotphylum", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches


taxa_barplot(taxasumsSpecies, mymetadata, "Donor-status")
ggsave("barplotspecies", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches




mymetadata %>% left_join(taxonomy) %>% 

SVs<-t(SVs)
depths<-rowSums(SVs)
hist(depths, breaks=30)
otu.counts<-colSums(SVs>0)
hist(otu.counts, breaks=30)


clr<-apply(log2(SVs+0.5), 2, function(x) x-mean(x))
clr %>%
  as.data.frame() %>%
  rownames_to_column("") %>%
  gather(-Feature.ID, key=SampleID, value=CLR) %>%
  filter(Feature.ID=="4b5eeb300368260019c1fbc7a3c718fc") %>%
  left_join(metadata) %>%
  filter(`body-site`=="gut") %>%
  ggplot(aes(x=subject, y=CLR, fill=subject)) +
  stat_summary(geom="bar", color="black") +
  geom_jitter(width=0.2, height=0, shape=21) +
  theme_q2r() +
  theme(legend.position="none")
ggsave("aldexbar.pdf", height=2, width=1.5, device="pdf")

