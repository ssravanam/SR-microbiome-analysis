library(qiime2R)
sv<-read_qza("Results/table-with-k-no-mitochondria-n0-chloroplast.qza")
sv$type
sv$contents
mymetadata<-read_tsv("Results/mymetadata.txt")
taxonomy<-read_qza("Results/taxonomy.qza")
head(taxonomy$data)
rooted
tree<-read_qza("Desktop/Results/rooted-tree.qza")
physeq<-qza_to_phyloseq(
  features="table-with-k-no-mitochondria-n0-chloroplast.qza",
  tree="rooted-tree.qza",
  taxonomy="taxonomy.qza",
  metadata = "mymetadata.txt"
)
library(tidyverse)
shannon<-read_qza("Results/shannon_vector.qza")
shannon<-shannon$data %>% rownames_to_column("SampleID")
gplots::venn(list(metadata=mymetadata$SampleID, shannon=shannon$SampleID))
ggsave("venn", height=4, width=4, device = pdf)
mymetadata<-
  mymetadata %>% 
  left_join(shannon)
mymetadata %>%
  filter(!is.na(shannon)) %>%
  ggplot(aes(x=`Donor-status`, y=shannon, fill=`Donor-status`)) +
  stat_summary(geom="bar", fun.data=mean_se, color="black") + #here black is the outline for the bars
  coord_cartesian(ylim=c(2,7)) + # adjust y-axis
  xlab("Four clinical groups") +   facet_grid(~'Shannon diversity index')
  ylab("Shannon Diversity") +
  theme_q2r() +
  scale_fill_manual(values=c("cornflowerblue","indianred")) + #specify custom colors
  theme(legend.position="none") +  #remove the legend as it isn't needed
ggsave("Shannon_diversity.pdf", height=3, width=4, device="pdf") # save a PDF 3 inches by 4 inches
#Evenness
evenness<-read_qza("qzv/alphadiversity/evenness_vector.qza")
evenness<-evenness$data %>% rownames_to_column("SampleID")
gplots::venn(list(metadata=mymetadata$SampleID, evenness=evenness$SampleID))
ggsave("vennevenness", height=4, width=4, device = pdf)
mymetadata<-
  mymetadata %>% 
  left_join(pielou_e)
mymetadata %>%
  filter(!is.na(pielou_e)) %>%
  ggplot(aes(x=`Donor-status`, y=pielou_e, fill=`Donor-status`)) +
  stat_summary(geom="bar", fun.data=mean_se, color="black") + #here black is the outline for the bars
  coord_cartesian(ylim=c(0.50,0.95)) + # adjust y-axis
  xlab("Four clinical groups") + facet_grid(~'Community evenness-pielou')
  ylab("Community Evenness") +
  theme_q2r() +
  scale_fill_manual(values=c("cornflowerblue","indianred")) + #specify custom colors
  theme(legend.position="none") + #remove the legend as it isn't needed
ggsave("evenness.pdf", height=3, width=4, device="pdf") # save a PDF 3 inches by 4 inches

#faithpd 
  faithpd<-read_qza("qzv/alphadiversity/faith_pd_vector.qza")
  faithpd<-faithpd$data %>% rownames_to_column("SampleID")
  gplots::venn(list(metadata=mymetadata$SampleID, faithpd=faithpd$SampleID))
  ggsave("vennfaithpd", height=4, width=4, device = pdf)
mymetadata<-
  mymetadata %>% 
  left_join(faithpd)
mymetadata %>%
  filter(!is.na(faithpd)) %>%
  ggplot(aes(x=`Donor-status`, y=faith_pd, fill=`Donor-status`)) +
  stat_summary(geom="bar", fun.data=mean_se, color="black") + #here black is the outline for the bars
  coord_cartesian(ylim=c(3,17)) + # adjust y-axis
  xlab("Four clinical groups") + facet_grid(~'Faith phylogenetic diversity')
  ylab("Faith PD") +
  theme_q2r() +
  scale_fill_manual(values=c("cornflowerblue","indianred")) + #specify custom colors
  theme(legend.position="none")+  #remove the legend as it isn't needed
ggsave("faithpd.pdf", height=3, width=4, device="pdf") # save a PDF 3 inches by 4 inches
  
#observed otus
obsotu<-read_qza("qzv/alphadiversity/observed_otus_vector.qza")
obsotu<-obsotu$data %>% rownames_to_column("SampleID")
  gplots::venn(list(metadata=mymetadata$SampleID, obsotu=obsotu$SampleID))
  ggsave("obs otu", height=4, width=4, device = pdf)
  
#PCOA
uwunifrac<-read_qza("Results/unweighted_unifrac_pcoa_results.qza")

uwunifrac$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  left_join(shannon) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`, size=shannon)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() +
  scale_size_continuous(name="Shannon Diversity") +
  scale_color_discrete(name="Donor-status")
ggsave("PCoA.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches

#uwunifrac
uwunifrac<-read_qza("qzv/betadiversity/unweighted_unifrac_pcoa_results.qza")
uwunifrac$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() + facet_grid(~'Unweighted unifrac')
  scale_color_discrete(name="Donor-status")
ggsave("unweightedPCoA.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches


#brays-curtis
Brays<-read_qza("qzv/betadiversity/bray_curtis_pcoa_results.qza")
Brays$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() + facet_grid(~'Bray Curtis')
scale_color_discrete(name="Donor-status")
ggsave("Braycurtis.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches

#Jaccard
jaccard<-read_qza("qzv/betadiversity/jaccard_pcoa_results.qza")
jaccard$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() + facet_grid(~'Jaccard')
scale_color_discrete(name="Donor-status")
ggsave("jaccard.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches


#wunifrac
wunifrac<-read_qza("qzv/betadiversity/weighted_unifrac_pcoa_results.qza")
wunifrac$data$Vectors %>%
  select(SampleID, PC1, PC2) %>%
  left_join(mymetadata) %>%
  ggplot(aes(x=PC1, y=PC2, color=`Donor-status`)) +
  geom_point(alpha=0.5) + #alpha controls transparency and helps when points are overlapping
  theme_q2r() + facet_grid(~'Weighted unifrac')
scale_color_discrete(name="Donor-status")
ggsave("WeightedPCoA.pdf", height=4, width=5, device="pdf") # save a PDF 3 inches by 4 inches


#heatmap
sv<-read_qza("qzv/table-with-k-no-mitochondria-n0-chloroplast.qza")$data
taxonomy<-read_qza("taxonomy.qza")$data %>% parse_taxonomy()
taxasumsgenus<-summarize_taxa(sv, taxonomy)$Genus
taxa_heatmap(taxasumsgenus, mymetadata, "Donor-status")
ggsave("heatmapgenus", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches

taxasumsPhylum<-summarize_taxa(sv, taxonomy)$Phylum
taxa_heatmap(taxasumsPhylum, mymetadata, "Donor-status")
ggsave("heatmapPhylum", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches

taxasumsSpecies<-summarize_taxa(sv, taxonomy)$Species
taxa_heatmap(taxasumsSpecies, mymetadata, "Donor-status")
ggsave("heatmapSpecies", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches

library(tidyverse)

taxa_barplot(taxasumsgenus, mymetadata, "Donor-status")
ggsave("barplotgenus", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches


taxa_barplot(taxasumsPhylum, mymetadata, "Donor-status")
ggsave("barplotphylum", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches


taxa_barplot(taxasumsSpecies, mymetadata, "Donor-status")
ggsave("barplotspecies", height=4, width=8, device="pdf") # save a PDF 4 inches by 8 inches




mymetadata %>% left_join(taxonomy) %>% 

SVs<-t(SVs)
depths<-rowSums(SVs)
hist(depths, breaks=30)
otu.counts<-colSums(SVs>0)
hist(otu.counts, breaks=30)


clr<-apply(log2(SVs+0.5), 2, function(x) x-mean(x))
clr %>%
  as.data.frame() %>%
  rownames_to_column("") %>%
  gather(-Feature.ID, key=SampleID, value=CLR) %>%
  filter(Feature.ID=="4b5eeb300368260019c1fbc7a3c718fc") %>%
  left_join(metadata) %>%
  filter(`body-site`=="gut") %>%
  ggplot(aes(x=subject, y=CLR, fill=subject)) +
  stat_summary(geom="bar", color="black") +
  geom_jitter(width=0.2, height=0, shape=21) +
  theme_q2r() +
  theme(legend.position="none")
ggsave("aldexbar.pdf", height=2, width=1.5, device="pdf")


########


library(microbiomeSeq)
library("phyloseq")
library("ggplot2")
physeq=matrix(sample(1:100, 100, replace = TRUE, nrow =10, ncol=10))



otu=otu_table(as.matrix(myotu), taxa_are_rows = FALSE)
tax=tax_table(as.matrix(taxonomy))
sam=sample_data(mymetadata)
otu_tree<-compute.brlen(tree, method="Grafen")
physeq<-merge_phyloseq(phyloseq(otu, tax), rootedtree, sam)

taxa_names(otu)

myotu<-t(SVs)

physeq<-taxa_level(physeq, which_level = "Genus")
co_occur<-co_occurence_network(physeq, grouping_column ="Donor.status", rhos=0.35, method = "cor", 
qval_threshold = 0.05, select.condition = "V", scale.vertex.size = 4, 
scale.edge.width = 15, plotNetwork = T, plotBetweennessEeigenvalue = F)



physeq.f
ntaxa(physeq.f)
nsamples(physeq.f)
sample_names(physeq.f)[1:5]
sample_variables(physeq)

nsamples(tree)
sample_names(physeq.f)[1:5]
colnames(rootedtree)

print(physeq)
physeq <- normalise_data(physeq.f, norm.method = "relative", norm.meta = T)
physeq <- normalise_data(physeq.f, norm.method = "scale", type = "log")
physeq <- normalise_data(physeq.f, norm.method = "scale", type = "sqrt")
p <- plot_anova_diversity(physeq.f, method = c("richness", "simpson", "shannon"),
grouping_column = "Donor.status", pValueCutoff = 0.05)

physeq <- taxa_level(physeq, which_level = "Genus")
co_occr <- co_occurence_network(physeq, grouping_column = "Donor.status", rhos = 0.35, 
                                method = "cor", qval_threshold = 0.05, select.condition = "V", scale.vertex.size = 4, 
                                scale.edge.width = 15, plotNetwork = T, plotBetweennessEeigenvalue = F)


ij4 <- make_network(physeq.f, type="samples", distance="jaccard",          max.dist = 0.4, 
                    keep.isolates=FALSE)

sampledata = data.frame(sample_data(physeq.f))
d1 = as.matrix(phyloseq::distance(physeq.f, method="jaccard"))
gr = graph.adjacency(d1, mode = "undirected", weighted = TRUE)

net = igraph::mst(gr)
V(net)$id = sampledata[names(V(net)), "Sample_ID"]
V(net)$Donor.status = sampledata[names(V(net)), "family_relationship"]

gnet=ggnetwork(net)

ggplot(gnet, aes(x = x, y = y, xend = xend, yend = yend))+
  geom_edges(color = "darkgray") +
  geom_nodes(aes(color = id, shape = litter)) + theme_blank()+
  theme(legend.position="bottom")
gt = graph_perm_test(physeq.f, "Donor.status" distance ="jaccard",
                     type="mst",  nperm=1000)


########2

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install(version = "3.11")
library(devtools)  
install_github("ramellose/CoNetinR")  
library(CoNetinR) 

library(devtools)
install_github("hallucigenia-sparsa/seqgroup")
all
##all

library(devtools)
install_github("zdk123/SpiecEasi")
library(SpiecEasi)
spiec.out=spiec.easi(physeq, method="mb",icov.select.params=list(rep.num=20))
spiec.graph=adj2igraph(getRefit(spiec.out), vertex.attr=list(name=taxa_names(physeq.f)))
plot_network(spiec.graph, physeq.f, type='taxa')
